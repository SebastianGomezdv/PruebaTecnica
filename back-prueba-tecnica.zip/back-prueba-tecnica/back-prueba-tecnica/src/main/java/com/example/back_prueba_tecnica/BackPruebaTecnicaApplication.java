package com.example.back_prueba_tecnica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackPruebaTecnicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackPruebaTecnicaApplication.class, args);
	}

}
