package com.example.back_prueba_tecnica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackPruebaTecnicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
